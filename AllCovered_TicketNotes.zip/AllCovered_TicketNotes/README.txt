READ ME

Purpose : create a web app that would easily copy, export and save ticket entries

8/20/2022 - completed design of web app.
8/21/2022 - New Entry Button working partially,
8/27/2022 - Copy button working to copy all entries of the form to clipboard



To Do:
TextArea - create default bullets
Buttons - Add functionality to New Entry, Copy and export.
  newEntry - add functionality to append input to a csv file.



Button Functions
New Entry - save filled form to csv file then clear entries
Copy - copy all entries to clipboard - DONE
Export - export a copy of the CSV file to user preferred location
