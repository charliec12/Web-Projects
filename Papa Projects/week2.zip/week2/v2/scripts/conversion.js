function display(){
  var gallons = document.getElementById("gallons").value;

  document.getElementById("result").innerHTML = gallons;
}
