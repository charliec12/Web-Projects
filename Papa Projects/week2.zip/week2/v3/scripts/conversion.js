function display(){
  var gallons = document.getElementById("slider").value;

  document.getElementById("result").innerHTML = gallons;
}
