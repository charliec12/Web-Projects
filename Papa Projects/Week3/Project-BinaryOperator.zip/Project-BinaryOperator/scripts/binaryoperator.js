function binaryAND(){
  var dataTable = document.getElementById('data');
  var binaryA;
  var binaryB;
  var binaryOp;
  var row;
  var binaryACell;
  var binaryBCell;
  var binaryOpCell;

  dataTable.innerHTML = '';

  //Header row
  var row = dataTable.insertRow(0);
  var aCell = row.insertCell(0);
  var bCell = row.insertCell(1);
  var opCell = row.insertCell(2);

  aCell.innerHTML = 'A';
  bCell.innerHTML = 'B';
  opCell.innerHTML = 'A||B';


    for(i=0;i<=1;i++){
      binaryA = i;
      for(j=0;j<=1;j++){
        binaryB = j;

        if(binaryA==binaryB){
          binaryOp=1;
          //Insert data
            row = dataTable.insertRow(-1);
            binaryACell = row.insertCell(0);
            binaryBCell = row.insertCell(1);
            binaryOpCell = row.insertCell(2);

            binaryACell.innerHTML = binaryA;
            binaryBCell.innerHTML = binaryB;
            binaryOpCell.innerHTML = binaryOp;

        }else{
          binaryOp=0;
          row = dataTable.insertRow(-1);
          binaryACell = row.insertCell(0);
          binaryBCell = row.insertCell(1);
          binaryOpCell = row.insertCell(2);

          binaryACell.innerHTML = binaryA;
          binaryBCell.innerHTML = binaryB;
          binaryOpCell.innerHTML = binaryOp;;
        }
      }
    }

}

function binaryOR(){
  var dataTable = document.getElementById('data');
  var binaryA;
  var binaryB;
  var binaryOp;
  var row;
  var binaryACell;
  var binaryBCell;
  var binaryOpCell;

  dataTable.innerHTML = '';

  //Header row
  var row = dataTable.insertRow(0);
  var aCell = row.insertCell(0);
  var bCell = row.insertCell(1);
  var opCell = row.insertCell(2);

  aCell.innerHTML = 'A';
  bCell.innerHTML = 'B';
  opCell.innerHTML = 'A||B';


    for(i=0;i<=1;i++){
      binaryA = i;
      for(j=0;j<=1;j++){
        binaryB = j;

        if(binaryA==1 || binaryB==1){
          binaryOp=1;
          //Insert data
            row = dataTable.insertRow(-1);
            binaryACell = row.insertCell(0);
            binaryBCell = row.insertCell(1);
            binaryOpCell = row.insertCell(2);

            binaryACell.innerHTML = binaryA;
            binaryBCell.innerHTML = binaryB;
            binaryOpCell.innerHTML = binaryOp;

        }else{
          binaryOp=0;
          row = dataTable.insertRow(-1);
          binaryACell = row.insertCell(0);
          binaryBCell = row.insertCell(1);
          binaryOpCell = row.insertCell(2);

          binaryACell.innerHTML = binaryA;
          binaryBCell.innerHTML = binaryB;
          binaryOpCell.innerHTML = binaryOp;;
        }
      }
    }

}

function binaryNOT(){
  var dataTable = document.getElementById('data');
  var binaryA;
  var binaryB;
  var binaryOp;
  var row;
  var binaryACell;
  var binaryBCell;
  var binaryOpCell;

  dataTable.innerHTML = '';

  //Header row
  var row = dataTable.insertRow(0);
  var aCell = row.insertCell(0);
  var bCell = row.insertCell(1);
  var opCell = row.insertCell(2);

  aCell.innerHTML = 'A';
  bCell.innerHTML = 'B';
  opCell.innerHTML = 'A||B';


    for(i=0;i<=1;i++){
      binaryA = i;
      for(j=0;j<=1;j++){
        binaryB = j;

        if(binaryA!=binaryB){
          binaryOp=1;
          //Insert data
            row = dataTable.insertRow(-1);
            binaryACell = row.insertCell(0);
            binaryBCell = row.insertCell(1);
            binaryOpCell = row.insertCell(2);

            binaryACell.innerHTML = binaryA;
            binaryBCell.innerHTML = binaryB;
            binaryOpCell.innerHTML = binaryOp;

        }else{
          binaryOp=0;
          row = dataTable.insertRow(-1);
          binaryACell = row.insertCell(0);
          binaryBCell = row.insertCell(1);
          binaryOpCell = row.insertCell(2);

          binaryACell.innerHTML = binaryA;
          binaryBCell.innerHTML = binaryB;
          binaryOpCell.innerHTML = binaryOp;;
        }
      }
    }

}

function binaryXOR(){
  var dataTable = document.getElementById('data');
  var binaryA;
  var binaryB;
  var binaryOp;
  var row;
  var binaryACell;
  var binaryBCell;
  var binaryOpCell;

  dataTable.innerHTML = '';

  //Header row
  var row = dataTable.insertRow(0);
  var aCell = row.insertCell(0);
  var bCell = row.insertCell(1);
  var opCell = row.insertCell(2);

  aCell.innerHTML = 'A';
  bCell.innerHTML = 'B';
  opCell.innerHTML = 'A||B';


    for(i=0;i<=1;i++){
      binaryA = i;
      for(j=0;j<=1;j++){
        binaryB = j;

        if(binaryA==0 && binaryB==0 || binaryA==1 && binaryB==1){
          binaryOp=0;
          //Insert data
            row = dataTable.insertRow(-1);
            binaryACell = row.insertCell(0);
            binaryBCell = row.insertCell(1);
            binaryOpCell = row.insertCell(2);

            binaryACell.innerHTML = binaryA;
            binaryBCell.innerHTML = binaryB;
            binaryOpCell.innerHTML = binaryOp;

        }else{
          binaryOp=1;
          row = dataTable.insertRow(-1);
          binaryACell = row.insertCell(0);
          binaryBCell = row.insertCell(1);
          binaryOpCell = row.insertCell(2);

          binaryACell.innerHTML = binaryA;
          binaryBCell.innerHTML = binaryB;
          binaryOpCell.innerHTML = binaryOp;;
        }
      }
    }

}
