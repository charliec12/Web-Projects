function hello() {
  document
    .write(
      "Hello from a JavaScript function"
    );
}