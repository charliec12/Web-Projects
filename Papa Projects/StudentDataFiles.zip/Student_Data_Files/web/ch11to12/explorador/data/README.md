Explorador Data
===============

parkDB.json should be loaded into the MongoDB database under a collection named "parks"