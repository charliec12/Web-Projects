thyroid-app-server
==================

Server-side companion to https://github.com/siddharthjn/Cancer-App

To get started:

```

  npm install
  node server.js

```
