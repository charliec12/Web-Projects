Thyroid-App
==========

** To set up for your server, you must set the SERVER_URL variable on line 1 in files Sync.js and UserForm.js, default is 127.0.0.1 **

Index.html : Main page for the app.

scripts/Advise.js : Suggestion page.

scripts/GraphAnimate.js : Graph Page.

scripts/Navigation.js : One time dialog, legal rider
